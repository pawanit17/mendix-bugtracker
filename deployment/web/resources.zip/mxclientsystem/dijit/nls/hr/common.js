//>>built
define("dijit/nls/hr/common",({buttonOk:"OK",buttonCancel:"Opoziv",buttonSave:"Spremi",itemClose:"Zatvori"}));
