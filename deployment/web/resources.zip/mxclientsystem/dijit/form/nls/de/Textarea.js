//>>built
define("dijit/form/nls/de/Textarea",({iframeEditTitle:"Editierbereich",iframeFocusTitle:"Rahmen für Editierbereich"}));
